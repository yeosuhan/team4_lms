package com.team4.myapp.member.dao;

import com.team4.myapp.member.model.Member;

public interface IMemberRepository {
	Member selectMember(String memberid);
	String getPassword(String memberid);
}
